async function buyStock(symbol) {
  const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
  const signer = new ethers.providers.Web3Provider(window.ethereum).getSigner();
  const dex = new ethers.Contract(DexAddress, DexABI, signer);
  await dex.buyStock(symbol, ethers.utils.parseEther("0.01"), { value: ethers.utils.parseEther("0.01") });
}