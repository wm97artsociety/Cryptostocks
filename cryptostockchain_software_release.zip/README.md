# CryptoStockChain
This is a mock demo of a blockchain-powered synthetic stock trading system.